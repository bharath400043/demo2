''''''
'''
MATRICES:
=============
row
column
         ___             ___
        |   10   25    5    |
        |                   |
A    =  |   32   12    7    |
        |                   |
        |__ 14   20    15 __|

Above is 3X3 matrix : Means 3 rows 3 columns   A[3X3]

A[2][1]  ==> 2nd row,1st column ==> 32
A[1][3]  ==> 1st row,3rd column ==>  5
A[2][2]  ==> 2nd row,2nd column ==> 12

'''